﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using q4;
using System;
using System.Collections.Generic;
using System.Text;

namespace q4.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        public void solveAnswerTest()
        {
            int n = 3;
            int m = 4;
            int[,] table = { { 1, 0, 0, 0 },{0,0,0,0 },{0,0,2,-1 } };
            bool[,] visited = { {true,false,false,false } ,{ false,false, false, false }, { false, false, false, false } };
            int emptyCount = 9;
            int iStart = 0;
            int iEnd = 2;
            int jStart = 0;
            int jEnd = 2;
            int pathNum = 0;
            int visitedCount = 0;
            Assert.AreEqual(2, Program.solveAnswer(iStart, jStart, ref visitedCount, iStart, jStart, table, visited, n, m, iEnd, jEnd, emptyCount, ref pathNum));
            n = 2;
            m = 2;
            int[,]table2 ={ { 0,1},{2,0 } };
            bool[,] visited2 = { { false, true }, { false, false } };
            emptyCount = 2;
            iStart = 0;
            jStart = 1;
            iEnd = 1;
            jEnd = 0;
            pathNum = 0;
            visitedCount = 0;
            Assert.AreEqual(0, Program.solveAnswer(iStart, jStart, ref visitedCount, iStart, jStart, table2, visited2, n, m, iEnd, jEnd, emptyCount, ref pathNum));

        }
    }
}