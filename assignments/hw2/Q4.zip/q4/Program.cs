﻿using System;

namespace q4
{
    public class Program
    {
		
		static void solve(ref int visitedCount,int x,int y,int[,] t, bool[,] v, int n, int m,int iEnd ,int jEnd,int emptyCount,ref int pathNum)
        {
            if (x == iEnd && y == jEnd)
            {
                if (visitedCount == emptyCount)
                {
					pathNum++;

                }
				return;
            }
            if (t[x, y] == 0)
            {
				visitedCount++;
				v[x, y] = true;
            }
            if (y + 1 < m && t[x, y + 1] != -1 && !v[x, y + 1])
            {
				solve(ref visitedCount, x, y + 1, t, v, n, m, iEnd, jEnd, emptyCount, ref pathNum);
            }
			if (y - 1 >= 0 && t[x, y - 1] != -1 && !v[x, y - 1])
			{
				solve(ref visitedCount, x, y - 1, t, v, n, m, iEnd, jEnd, emptyCount, ref pathNum);
			}
			if (x + 1 < n && t[x + 1, y] != -1 && !v[x+ 1, y ])
			{
				solve(ref visitedCount, x + 1, y , t, v, n, m, iEnd, jEnd, emptyCount, ref pathNum);
			}
			if (x - 1 >=0 && t[x - 1, y] != -1 && !v[x - 1, y])
			{
				solve(ref visitedCount, x - 1, y, t, v, n, m, iEnd, jEnd, emptyCount, ref pathNum);
			}
			v[x, y] = false;
            visitedCount--;
		}
        public static int solveAnswer(int iStart,int jStart,ref int visitedCount, int x, int y, int[,] t, bool[,] v, int n, int m, int iEnd, int jEnd, int emptyCount, ref int pathNum)
        {
            solve(ref visitedCount, iStart, jStart, t, v, n, m, iEnd, jEnd, emptyCount, ref pathNum);
            return pathNum;
        }
        static void Main(string[] args)
        {
            string[] nums = Console.ReadLine().Split(' ');
            int n = int.Parse(nums[1]);
            int m = int.Parse(nums[0]);
            int[,] table = new int[n, m];
			bool[,] visited = new bool[n, m];
			int emptyCount = 0;
            int iStart = 0;
            int iEnd=0;
            int jStart = 0;
            int jEnd=0;
			int pathNum = 0;
            int visitedCount=0;
            for (int i = 0; i < n; i++)
            {
                nums = Console.ReadLine().Split(' ');
                for(int j = 0; j < m; j++)
                {
                    table[i, j] =int.Parse(nums[j]);
					visited[i, j] = false;
                    if (table[i, j] == 0)
                    {
						emptyCount++;
                    }else if (table[i, j] == 1)
                    {
						iStart = i;
						jStart = j;
                        visited[i, j] = true;
                    }
					else if (table[i, j] == 2)
                    {
						iEnd = i;
						jEnd = j;
                    }
                }
            }
            solve(ref visitedCount, iStart, jStart, table,visited, n, m, iEnd, jEnd, emptyCount, ref pathNum);
            Console.WriteLine(pathNum);
        }
    }
}
