﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using q3;
using System;
using System.Collections.Generic;
using System.Text;

namespace q3.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        public void nextDirectionTest()
        {
            Assert.AreEqual('u',Program.nextDirection('l'));
            Assert.AreEqual('d', Program.nextDirection('r'));
        }

        [TestMethod()]
        public void goTest()
        {
            int[][] matrix = new int[4][];
            bool[][] v = new bool[4][];
            for(int i = 0; i < 4; i++)
            {
                matrix[i] = new int[4];
                v[i] = new bool[4];
            }
            for(int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    matrix[i][j] = 4*i + j + 1;
                    v[i][j]= false;
                }
            }
            v[0][0] = true;
            Assert.AreEqual(",2,3,4,8,12,16,15,14,13,9,5,6,7,11,10",Program.go(matrix,4,4,v,0,0,'r'));
            int[][] matrix2 = new int[4][];
            bool[][] v2 = new bool[4][];
            for (int i = 0; i < 4; i++)
            {
                matrix[i] = new int[3];
                v[i] = new bool[3];
            }
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    matrix[i][j] = 3 * i + j + 1;
                    v[i][j] = false;
                }
            }
            v[0][0] = true;
            Assert.AreEqual(",2,3,6,9,12,11,10,7,4,5,8", Program.go(matrix, 4, 3, v, 0, 0, 'r'));
        }
    }
}