﻿
using System;
namespace q3
{
    public class Program
    {
        public static char nextDirection(char c)
        {
            if (c == 'r')
            {
                return 'd';
            } else if (c == 'd')
            {
                return 'l';
            } else if (c == 'l')
            {
                return 'u';
            } else if (c == 'u')
            {
                return 'r';
            }
            return ' ';
        }
        public static string go(int[][] matrix,int row,int col,bool[][] visited,int startRow,int startCol,char direction)
        {
            string ans = "";
            if (direction == 'r')
            {
                for (int i = startCol + 1; i < col; i++)
                {
                    if (visited[startRow][i])
                    {
                        if (startCol + 1 == i)
                        {
                            return "";
                        }
                        else
                        {
                            direction = nextDirection(direction);
                            return ans+go(matrix, row, col, visited, startRow, i - 1, direction);
                        }
                    }
                    visited[startRow][i] = true;
                    //Console.Write(",{0}", matrix[startRow][i]);
                    ans += ",";
                    ans += matrix[startRow][i].ToString();
                }
                direction = nextDirection(direction);
                return ans + go(matrix, row, col, visited, startRow, col - 1, direction);
            }
            else if (direction == 'l')
            {
                for (int i = startCol - 1; i >= 0; i--)
                {
                    if (visited[startRow][i])
                    {
                        if (startCol - 1 == i)
                        {
                            return "";
                        }
                        else
                        {
                            direction = nextDirection(direction);
                            return ans + go(matrix, row, col, visited, startRow, i + 1, direction);
                        }
                    }
                    visited[startRow][i] = true;
                    //Console.Write(",{0}", matrix[startRow][i]);
                    ans += ",";
                    ans += matrix[startRow][i].ToString();
                }
                direction = nextDirection(direction);
                return ans + go(matrix, row, col, visited, startRow, 0, direction);
            }
            else if (direction == 'd')
            {
                for (int i = startRow + 1; i < row; i++)
                {
                    if (visited[i][startCol])
                    {
                        if (startRow + 1 == i)
                        {
                            return "";
                        }
                        else
                        {
                            direction = nextDirection(direction);
                            return ans + go(matrix, row, col, visited, i - 1, startCol, direction);
                        }
                    }
                    visited[i][startCol] = true;
                    //Console.Write(",{0}", matrix[i][startCol]);
                    ans += ",";
                    ans += matrix[i][startCol].ToString();
                }
                direction = nextDirection(direction);
                return ans + go(matrix, row, col, visited, row - 1, startCol, direction);
            }
            else if (direction == 'u')
            {
                for (int i = startRow - 1; i >= 0; i--)
                {
                    if (visited[i][startCol])
                    {
                        if (startRow - 1 == i)
                        {
                            return "";
                        }
                        else
                        {
                            direction = nextDirection(direction);
                            return ans + go(matrix, row, col, visited, i + 1, startCol, direction);
                        }
                    }
                    else
                    {
                    visited[i][startCol] = true;
                    //Console.Write(",{0}", matrix[i][startCol]);
                        ans += ",";
                        ans += matrix[i][startCol].ToString();
                    }
                    
                }
                direction = nextDirection(direction);
                return ans + go(matrix, row, col, visited, row + 1, startCol, direction);
            }
            else
                return "";
        
        }
        static void Main(string[] args)
        {
            char direction = 'r';
            int row, col;
            Console.WriteLine("enter number of rows");
            row=int.Parse(Console.ReadLine());
            Console.WriteLine("enter number of columns");
            col = int.Parse(Console.ReadLine());
            int[][] matrix = new int[row][];
            bool[][] visited = new bool[row][];
            string[] numbers;
            Console.WriteLine("enter numbers in each row");
            for (int i = 0; i < row; i++)
            {
                matrix[i] = new int[col];
                numbers = Console.ReadLine().Split(' ');
                int[] nums = Array.ConvertAll(numbers, int.Parse);
                visited[i] = new bool[col];
                for(int j = 0; j < col; j++)
                {
                    matrix[i][j] = nums[j];
                    visited[i][j] = false;
                }
            }
           
            Console.Write("{0}",matrix[0][0]);
            visited[0][ 0] = true;
            Console.WriteLine(go(matrix, row, col, visited, 0, 0, direction));
           
        }
    }
}
