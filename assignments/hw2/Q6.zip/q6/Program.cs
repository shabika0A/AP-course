﻿using System;

namespace q6
{
    public class Program
    {
        public static string Solve(int l,int r,int tenantCount, int[,] times)
        {
            int remain = tenantCount;
            bool[] visited = new bool[tenantCount];
            for (int i = 0; i < tenantCount; i++)
            {
                visited[i] = false;
                if (times[i, 1] < l || times[i, 0] > r)
                {
                    visited[i] = true;
                    remain--;
                }
            }
            int point = times[0,1];
            string ans = "";
            int pnumber = 0;
            while (remain > 0)
            {
                for(int i = 0; i < tenantCount; i++)//select point
                {
                    if (!visited[i])
                    {
                        point = times[i, 1];
                        break;
                    }
                }
                for (int i = 0; i < tenantCount; i++)//select smalest point
                {
                    if (times[i,1] < point && !visited[i])
                    {
                        point = times[i,0];

                    }
                }
                int j = 0;
                for (int i = 0; i < tenantCount; i++)
                {
                    if (!visited[i] && times[i, 0] <= point && times[i, 1] >= point)
                    {
                        remain--;
                        visited[i] = true;
                        pnumber++;
                    }
                }
                ans+=point.ToString();
                ans += ' ';

            }
            Console.WriteLine(pnumber);
            return ans;
        }
            static void Main()
        {
            string[] numbers = Console.ReadLine().Split(' ');
            int l = int.Parse(numbers[0]);
            int r = int.Parse(numbers[1]);
            int n = int.Parse(Console.ReadLine());
            int[,] times = new int[n, 2];
            for(int i = 0; i < n; i++)
            {
                numbers = Console.ReadLine().Split(' ');
                times[i,0]= int.Parse(numbers[0]);
                times[i,1]= int.Parse(numbers[1]);
            }
           Console.WriteLine( Solve(l, r, n, times));
        }
    }
}
