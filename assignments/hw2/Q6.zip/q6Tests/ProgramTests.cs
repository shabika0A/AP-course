﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using q6;
using System;
using System.Collections.Generic;
using System.Text;

namespace q6.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        public void SolveTest()
        {
            int[,] times = { { 3, 6 }, { 1, 2 }, { 7, 8 } };
            Assert.AreEqual("6 8 ",Program.Solve(3,7,3,times));
            int[,] time2 = { { 1, 3 }, { 4, 7 }, { 6, 8 }, { 7, 8 }, { 8, 9 } };
            Assert.AreEqual("7 9 ", Program.Solve(6, 10, 5, time2));
        }
    }
}