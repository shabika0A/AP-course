﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using q5;
using System;
using System.Collections.Generic;
using System.Text;

namespace q5.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        public void zerosmorethan3Test()
        {
        int[,] t = { { 0, 8, 4, 0, 0, 0, 0, 1, 3 }, { 2, 0, 0, 0, 3, 0, 6, 0, 0 }, { 6, 0, 0, 5, 0, 9, 0, 0, 2 }, { 0, 0, 2, 0, 0, 0, 4, 6, 9 }, { 7, 0, 0, 0, 0, 0, 0, 0, 0 }, { 0, 0, 0, 2, 8, 0, 0, 0, 0 }, { 0, 2, 0, 7, 0, 0, 0, 0, 0 }, { 0, 0, 8, 0, 0, 5, 9, 0, 6 }, { 5, 0, 0, 0, 2, 0, 3, 0, 7 } };
        Assert.AreEqual(true,Program.zerosmorethan3(t));
        int[,] t2 = { { 0, 8, 4, 6, 7, 2, 5, 1, 3 }, { 2, 5, 7, 8, 3, 1, 6, 9, 4 }, { 6, 1, 3, 5, 4, 9, 8, 7, 2 }, { 8, 3, 2, 1, 5, 7, 4, 6, 9 }, { 7, 4, 5, 3, 9, 6, 2, 8, 1 }, { 1, 9, 6, 2, 8, 4, 7, 3, 5 }, { 4, 2, 9, 7, 6, 3, 4, 5, 8 }, { 3, 7, 8, 4, 1, 5, 9, 2, 6 }, { 5, 6, 1, 9, 2, 8, 3, 4, 7 } };
        Assert.AreEqual(false, Program.zerosmorethan3(t2));
        }
        [TestMethod()]
        public void tablesolved()
        {
            var ta = new Program.table();
            Assert.AreEqual(false, ta.solved());
        }
        /*[TestMethod()]
        public void menuTest()
        {
            Assert.AreEqual('a', Program.menu());
        }*/
    }
}