﻿using System;

namespace q5
{
    public class Program
    {
        public static bool zerosmorethan3(int[,] a)
        {
            int counter = 0;
            for(int i = 0; i < 9; i++)
            {
                for(int j = 0; j < 9; j++)
                {
                    if (a[i, j] == 0)
                    {
                        counter++;
                        if (counter >= 3)
                        {
                            return true;
                        }
                    }
                }
            }
                return false;
        }
        public class table
        {
            public int row=9;
            public int col=9;
            public int[,] t ={ { 0,8,4,0,0,0,0,1,3 }, { 2,0,0,0,3,0,6,0,0 } ,{ 6,0,0,5,0,9,0,0,2 },{ 0,0,2,0,0,0,4,6,9},{ 7,0,0,0,0,0,0,0,0},{ 0,0,0,2,8,0,0,0,0},{ 0,2,0,7,0,0,0,0,0},{0,0,8,0,0,5,9,0,6 },{ 5,0,0,0,2,0,3,0,7} };
            public bool[,] user=new bool[9,9];
            public int[,] ans= { { 9,8,4,6,7,2,5,1,3},{ 2,5,7,8,3,1,6,9,4},{ 6,1,3,5,4,9,8,7,2},{ 8,3,2,1,5,7,4,6,9},{ 7,4,5,3,9,6,2,8,1},{1,9,6,2,8,4,7,3,5 },{4,2,9,7,6,3,4,5,8 },{3,7,8,4,1,5,9,2,6 },{5,6,1,9,2,8,3,4,7 } };
            int hintNum = 3;
            public table()
            {
                for (int i = 0; i < 9; i++)
                {
                    for (int j = 0; j < 9; j++)
                    {
                        user[i, j] = false;
                    }
                }
                
            }
            public void add()
            {
                string[] numbers = Console.ReadLine().Split(' ');
                int[] input = Array.ConvertAll(numbers, int.Parse);
                //]row] [column] [number[
                if (t[input[0], input[1]] != 0)
                {
                    Console.WriteLine("this place already has a number!");
                    return;
                }
                else
                {
                    if (input[2] > 9 || input[2] < 1)
                    {
                        Console.WriteLine("number is out of range!");
                        return;
                    }
                    t[input[0], input[1]] = input[2];
                    user[input[0], input[1]] = true;
                    Console.WriteLine("number wass added successfully");
                }
            }
            public void delete()
            {
                string[] numbers = Console.ReadLine().Split(' ');
                int[] input = Array.ConvertAll(numbers, int.Parse);
                if (t[input[0], input[1]] ==0 )
                {
                    Console.WriteLine("this place is empty!");
                }else if(!user[input[0], input[1]])
                {
                    Console.WriteLine("you can not delete this number!");
                }
                else
                {
                    t[input[0], input[1]] = 0;
                    user[input[0], input[1]] = false;
                    Console.WriteLine("number wass removed successfully");
                }

            }
            public void hint()
            {
                if (hintNum == 0)
                {
                    Console.WriteLine("there is no hint available!");
                }
                else
                {
                    hintNum--;
                    if (zerosmorethan3(t))
                    {
                        int counter = 0;
                        Random rnd = new Random();
                        int r, c;
                        while (counter < 3)
                        {
                             r = rnd.Next(0, 8);
                             c= rnd.Next(0, 8);
                            if (t[r, c] == 0)
                            {
                                t[r, c] = ans[r, c];
                                counter++;
                            }

                        }
                        Console.WriteLine("3 numbers have been added to the table successfully .");
                    }
                    else
                    {
                        Console.WriteLine("number of empty places is less than 3");
                    }
                }
            }
            public void show()
            {
                for (int i = 0; i < 9; i++)
                {
                    for (int j = 0; j < 9; j++)
                    {
                        if(t[i,j]!=0&& !user[i, j])
                        {
                            Console.ForegroundColor= ConsoleColor.Cyan;
                            Console.Write("{0} ", t[i, j]);
                            Console.ForegroundColor = ConsoleColor.White;
                        }
                        else
                        {
                            Console.Write("{0} ", t[i, j]);
                        }
                    }
                    Console.WriteLine();
                }
            }
            public void exit()
            {
                int solved = 0;
                int remained = 0;
                for (int i = 0; i < 9; i++)
                {
                    for (int j = 0; j < 9; j++)
                    {
                        if (t[i, j] == 0)
                        {
                            remained++;
                        }
                        if (t[i, j] != 0 && user[i, j])
                        {
                            solved++;
                        }
                    }
                }
                Console.WriteLine("Exited successfully. solved number:{0} remained number:{1}",solved,remained);
            }
            public bool solved()
            {
                for (int i = 0; i < 9; i++)
                {
                    for (int j = 0; j < 9; j++)
                    {
                        if (t[i, j] == 0)
                        {
                            return false;
                        }
                        for(int k = j+1; k < 9; k++)
                        {
                            if (t[i, j] == t[i, k]||t[j,i]==t[k,i])
                            {
                                return false;
                            }
                        }
                    }
                }
                //check squares
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        int[] s = { t[3 * i, 3 * j], t[3 * i + 1, 3 * j], t[3 * i + 2, 3 * j], t[3 * i + 1, 3 * j + 1], t[3 * i + 2, 3 * j + 1], t[3 * i, 3 * j + 1], t[3 * i, 3 * j + 2], t[3 * i + 1, 3 * j + 2], t[3 * i + 2, 3 * j + 2] };
                        for(int k = 0; k < 9; k++)
                        {
                            for(int p = k+1; p < 9; p++)
                            {
                                if (s[p] == s[k])
                                {
                                    return false;
                                }
                            }
                        }
                    }
                }
                Console.WriteLine("table is solved =)");
                return true;
            }
        }
        public static char menu()
        {
            Console.WriteLine("1. Add number");
            Console.WriteLine("2. Delete number");
            Console.WriteLine("3. Hint");
            Console.WriteLine("4. Show table");
            Console.WriteLine("5. Exit");
            Console.WriteLine("please enter item number: ");
            int ans = int.Parse(Console.ReadLine());
            switch (ans)
            {
                case 1:
                    return 'a';
                case 2:
                    return 'd';
                case 3:
                    return 'h';
                case 4:
                    return 's';
                case 5:
                    return 'e';
            }
            return ' ';
        }
        static void Main(string[] args)
        {
            table t=new table();
            bool s = false;//for solve
            bool exit = false;
            char command;
            int p = 9;
            while (!s && !exit)
            {
                command=menu();
                switch (command)
                {
                    case 'e':
                        exit = true;
                        t.exit();
                        break;
                    case 'a':
                        t.add();
                        break;
                    case 'd':
                        t.delete();
                        break;
                    case 'h':
                        t.hint();
                        break;
                    case 's':
                        t.show();
                        break;
                }
                s = t.solved();
            }
        }
    }
}
