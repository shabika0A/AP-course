﻿using System;

namespace q7
{
    public class Program
    {
        public class Stocks
        {
            int TotalCash;
            int[] StockValues;//ta 100 rooz
            //public int[,] BuyStockMethods(int[] valuesPerDay)
            //{
            //    //hame halat ha
            //}
            public static void func(int totalCash,int[] sortedvalues,int bigOrder, int[,] ans,ref int i,ref int j)
            {
                if (totalCash == 0)
                {
                    i++;
                    j = 0;
                    return;
                }
                while (bigOrder >= 0)
                {
                    if (bigOrder == 0)
                    {
                        if(totalCash>0&&totalCash% sortedvalues[bigOrder]!=0)
                        {
                            for(int k = j; k >= 0; k--)
                            {
                                ans[i, j] = 0;
                            }
                            j = 0;
                            return;
                        }
                        else { 
                        for (int p = 1; p <= totalCash / sortedvalues[bigOrder]; p++)
                        {
                            
                                ans[i, j] = sortedvalues[bigOrder];
                                j++;
                            
                            //delete and solve for smaller
                        }
                        i++;
                        j = 0;
                        bigOrder--;
                        return;}
                    }
                    else { 
                    for(int p = 1; p <= totalCash / sortedvalues[bigOrder];p++)
                    {
                        for(int k = 1; k <= p; k++)//p ta bozorg bezar
                        {
                            ans[i, j] = sortedvalues[bigOrder];
                            j++;
                        }
                        //delete and solve for smaller
                        func(totalCash - sortedvalues[bigOrder] * p,sortedvalues,bigOrder-1,ans,ref i,ref j);
                    }
                    bigOrder--;
                }}
            }
            public static int[,] funcAnswer(int totalCash, int[] sortedvalues, int bigOrder, int[,] ans, ref int i, ref int j)
            {
                func(totalCash, sortedvalues, bigOrder, ans, ref i, ref j);
                return ans;
            }
            //public int BestPeriods(){
            //    //bishtarin sood
            //}
        }
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            //int[] v = { 1, 2, 3 };
            //int[,] a = { { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } };
            int i = 0;
            int j = 0;
            //Console.WriteLine(Stocks.funcAnswer(4, v, 2, a, ref i, ref j));
            int[] v = { 2,3,5,6 };
            int[,] a2 = { { 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0 }, { 0, 0, 0, 0, 0 } , { 0, 0, 0, 0, 0 } };
            Stocks.funcAnswer(10, v, 3, a2, ref i, ref j);
            Console.WriteLine();
        }
    }
}
