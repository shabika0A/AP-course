﻿using System;

namespace q2
{
    public class Program
    {
       
        public static string chap(int n)
        {
        String[] units = { "zero", "one", "two", "three","four", "five", "six", "seven", "eight", "nine","ten", "eleven","twelve", "thirteen", "fourteen", "fifteen","sixteen","seventeen", "eighteen", "nineteen" };
        String[] tens = { "", "", "twenty", "thirty", "forty","fifty", "sixty", "seventy", "eighty", "ninety" };
            string ans = "";
            if (n < -999)
            {
                
                return "Too Small";
            }else if (n > 999)
            {
                
                return "Too Large";
            }
            else
            {
                if (n == 0)
                {
                    return ans;
                }
                if (n < 0)
                {
                    
                    ans += "minus ";
                    n = 0 - n;
                }
                if (n < 20)
                {
                    
                    ans += units[n].ToString();
                    ans += " ";
                    return ans;
                } else if (n < 100)
                {
                    ans += tens[n / 10].ToString();
                    ans += " ";
                    return ans+chap(n % 10);
                }
                else {
                    ans += units[n / 100].ToString();
                    ans += "-hundred and ";
                    return ans +chap(n % 100);
                }
                //return "";

            }
        }
        public static void Main(string[] args)
        {
            int n;
            n = int.Parse(Console.ReadLine());
            Console.WriteLine(chap(n));
        }
            
    }
}
