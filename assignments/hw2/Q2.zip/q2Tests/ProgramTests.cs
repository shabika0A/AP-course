﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using q2;
using System;
using System.Collections.Generic;
using System.Text;

namespace q2.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        public void chapTest()
        {
            Assert.AreEqual("minus four-hundred and twenty ", Program.chap(-420));
            Assert.AreEqual("Too Large", Program.chap(98754));
            Assert.AreEqual("Too Small", Program.chap(-75368));
        }

        
    }
}