﻿using System;

namespace Q1HW2
{
    public class Program
    {
        public static bool aval(int a, int b)
        {
            for (int i = 2; i <= a; i++)
            {
                if (a % i == 0 && b % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
        public static bool khoob(int[] a)
        {
            for (int i = 0; i < a.Length; i++)
            {
                for (int j = i + 1; j < a.Length; j++)
                {
                    if (aval(a[i], a[j]))
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        public static void Main(string[] args)
        {
            int n;
            n = int.Parse(Console.ReadLine());
            string[] numbers = Console.ReadLine().Split(' ');
            int[] nums = Array.ConvertAll(numbers, int.Parse);
            Console.WriteLine(khoob(nums));
        }
    }
}
