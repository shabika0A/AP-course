﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Q1HW2;
using System;
using System.Collections.Generic;
using System.Text;

namespace Q1HW2.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        public void khoobTest()
        {
            int[] a = { 12, 5, 7, 23 };
            Assert.AreEqual(true, Program.khoob(a));
            int[] b = { 3, 6 };
            Assert.AreEqual(false, Program.khoob(b));
        }
        [TestMethod()]
        public void avalTest()
        {
            Assert.AreEqual(true, Program.aval(4, 9));
            Assert.AreEqual(false, Program.aval(6, 15));
        }
    }
}